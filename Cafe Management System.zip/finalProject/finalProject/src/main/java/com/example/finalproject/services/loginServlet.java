package com.example.finalproject.services;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

@WebServlet(name = "loginServlet", value = "/loginServlet")
public class loginServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String dbemail=null;
        String dbpss=null;
        String email=request.getParameter("email");
        String password=request.getParameter("password");
        System.out.println(email);
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/cafemanagement", "root", "root");
            // Step 2:Create a statement using connection object
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery("SELECT * from cafe");
            while (rs.next()){
                if(email.equals(rs.getString("email")) && password.equals(rs.getString("password"))){
                    dbemail=rs.getString("email");
                    dbpss= rs.getString("password");

                    break;
                }
            }
            System.out.println(dbemail);
            if (email.equals(dbemail) && password.equals(dbpss)){
                RequestDispatcher dispatcher=request.getRequestDispatcher("/index.jsp");
                dispatcher.forward(request,response);
                System.out.println("you sucessful enter");
            }else {
                response.setContentType("Text/Html");
                PrintWriter out= response.getWriter();
                String msc="invalid password";
                out.print(msc);
                RequestDispatcher dispatcher=request.getRequestDispatcher("pages/login.jsp");
                dispatcher.include(request,response);
            }


        } catch (SQLException | ClassNotFoundException e) {
            // process sql exception
            System.out.println(e);
        }

    }
}
