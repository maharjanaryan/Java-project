package com.example.finalproject.services;

import javax.servlet.ServletException;
        import javax.servlet.annotation.WebServlet;
        import javax.servlet.http.HttpServlet;
        import javax.servlet.http.HttpServletRequest;
        import javax.servlet.http.HttpServletResponse;
        import java.io.IOException;
        import java.io.PrintWriter;

@WebServlet(name = "OrderServlet", value = {"/order"})
public class OrderServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve form data from the request
        String itemName = request.getParameter("item");
        int quantity = Integer.parseInt(request.getParameter("quantity"));

        // Process the order and generate a response
        String confirmationMessage = processOrder(itemName, quantity);

        // Send the response back to the client
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h1>Order Confirmation</h1>");
        out.println("<p>Thank you for ordering " + quantity + " " + itemName + "!</p>");
        out.println("<p>" + confirmationMessage + "</p>");
        out.println("</body></html>");
    }

    // Implement your order processing logic here
    private String processOrder(String itemName, int quantity) {
        // Add your business logic to process the order
        // You can connect to a database, update inventory, etc.
        return "Your order has been processed successfully.";
    }
}
